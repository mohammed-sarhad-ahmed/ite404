const express = require("express");
const app = express();
const ejs = require("ejs");
const cookieParser = require("cookie-parser");
const { json } = require("body-parser");
const method = require("method-override");
app.set("view engine", "ejs");
app.use(method("_method"));
app.use(express.urlencoded({ extended: json }));
app.use(cookieParser());
function eliminateItem(req, res, next) {
  const id = req.params.id;
  const itemIndex = req.cookies.tasks.findIndex((el) => +el.id === +id);
  req.cookies.tasks.splice(itemIndex, 1);
  next();
}

function deleter(req, res) {
  res.cookie("tasks", req.cookies.tasks);
  res.redirect(301, "/");
}

const updater = (req, res) => {
  const item = req.cookies.tasks.find((el) => +el.id === +req.params.id);
  res.cookie("editId", item.id, { path: "/replace" });
  res.status(200).type("html").render("taskform", { item });
};

app.get("/", (req, res) => {
  res.status(200).type("html").render("index", {
    tasks: req.cookies.tasks,
  });
});
app.post("/replace", (req, res) => {
  const itemIndex = req.cookies.tasks.findIndex(
    (el) => +el.id === req.cookies.editId
  );
  req.body.id = Date.now();
  res.clearCookie("editId");
  req.cookies.tasks.splice(itemIndex, 1, req.body);
  res.cookie("tasks", req.cookies.tasks, {});
  res.status(200).type("html").render("index", { tasks: req.cookies.tasks });
});
app.delete("/", (req, res) => {
  res.clearCookie("tasks");
  res.redirect("/");
});

app.route("/:id").delete(eliminateItem, deleter).patch(updater);

app.get("/addnew", (req, res) => {
  res.status(200).type("html").render("taskform", { item: null });
});
app.post("/taskform", (req, res) => {
  req.body.id = Date.now();
  if (!req.cookies.tasks) {
    res.status(200).cookie("tasks", [req.body], {});
  } else {
    res.cookie("tasks", [req.body, ...req.cookies.tasks], {});
  }
  res.redirect(301, "/");
});

app.listen(80, () => {
  console.log("we are starting a server at port 80");
});

// sources
//https://expressjs.com/en/resources/middleware/method-override.html#:~:text=To%20use%20a%20header%20to%20override%20the%20method%2C,overridden%20method%20as%20the%20value%20of%20that%20header.
